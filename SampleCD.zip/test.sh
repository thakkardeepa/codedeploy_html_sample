#!/bin/sh

cat /dev/urandom
